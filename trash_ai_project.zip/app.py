import tensorflow as tf
from tensorflow import keras
import gradio as gr
import numpy as np

print("AI Trash Sorter - Web App")
print("To run: python app.py")
