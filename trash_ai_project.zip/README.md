# AI Trash Sorter 🗑️♻️

A machine learning project that classifies trash as Recyclable or Organic using computer vision.

## What It Does
- Takes images of trash as input
- Uses a convolutional neural network to analyze the image
- Classifies as ♻️ Recyclable or 🍎 Organic
- Provides recycling advice

## Technical Details
- Built with TensorFlow/Keras
- Trained on 18,000+ trash images
- 85% validation accuracy
- Web interface built with Gradio

## Project Structure
- `trash_classifier.ipynb` - Main training code
- `app.py` - Web application
- `requirements.txt` - Dependencies
- `README.md` - This file

## Note
This project was developed as a learning exercise in AI/ML.
